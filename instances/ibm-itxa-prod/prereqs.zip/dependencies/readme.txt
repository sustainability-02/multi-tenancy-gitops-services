This folder consists of sample files required to create pre-reqs for ITXA deployment.
